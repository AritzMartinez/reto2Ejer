class Autor {
    constructor(dni,nombreaepellidoa){
        this.dni = dni;
        this.nombreaepellidoa = nombreaepellidoa;
    }
}