class Preguntas {
    constructor (pregunta,respuesta1,respuesta2,respuesta3,respuesta4,correcta) {
        this.pregunta = pregunta;
        this.respuesta1 = respuesta1;
        this.respuesta2 = respuesta2;
        this.respuesta3 = respuesta3;
        this.respuesta4 = respuesta4;
        this.correcta = correcta;
    }
}