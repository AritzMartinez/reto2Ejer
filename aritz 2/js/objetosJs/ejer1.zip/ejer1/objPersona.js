class Persona {
     // constructor donde definir las variables que se reciben y guardarlaen el objeto usando this
     constructor (nombre,organizacion,movil,campos) {
         this.nombre = nombre;
         this.organizacion = organizacion;
         this.movil = movil;
         this.campos = campos;
         }
}
