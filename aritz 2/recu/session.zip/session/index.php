<?php
session_start();
require_once "funciones_db.php";
require_once "datos.php";

if (isset($_GET['accion'])){
    $accion = $_GET['accion'];
    switch ($accion){
        case 'login':
            $_SESSION['usuario'] = $_GET["usu"];
            $contra = $_GET["contra"];

            echo "Hola " .$_SESSION['usuario'];

            foreach ($usuarios as $key => $usuario) {

                if($usuario['contrasena'] == $contra && $key == $_SESSION['usuario']){
                    require "views/principal.php";
                    die();
                }
            }
            break;
        case 'añadir':
            sessionEmpleado();
            insertaEmpleado($_GET["dni_empleado"], $_GET["nombre"], $_GET["domicilio"]);
            require "views/principal.php";
            die();
            break;
        case 'atender':
            marcarEmpleado($_GET["dni_empleado"]);
            require "views/principal.php";
            die();
            break;
        case 'borrar':
            borrarTodos();
            require "views/principal.php";
            die();
            break;

    }
}




require_once "views/usuario.php";
?>